## CS 285 Homework 2

All commands to run experiments are found in the `experiments` directory. Code to produce all plots, figures, and tables are found in the `plot.ipynb` file.