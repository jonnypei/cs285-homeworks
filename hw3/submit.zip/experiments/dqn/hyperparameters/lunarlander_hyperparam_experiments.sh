python cs285/scripts/run_hw3_dqn.py -cfg experiments/dqn/hyperparameters/lunarlander_n=2.yaml
python cs285/scripts/run_hw3_dqn.py -cfg experiments/dqn/hyperparameters/lunarlander_n=4.yaml
python cs285/scripts/run_hw3_dqn.py -cfg experiments/dqn/hyperparameters/lunarlander_n=6.yaml
python cs285/scripts/run_hw3_dqn.py -cfg experiments/dqn/hyperparameters/lunarlander_n=8.yaml
python cs285/scripts/run_hw3_dqn.py -cfg experiments/dqn/hyperparameters/lunarlander_n=10.yaml